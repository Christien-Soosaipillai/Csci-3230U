$(document).ready(function(){
$("#unitInfo tbody tr").click(function(){
   $(this).addClass('danger').siblings().removeClass('danger');   
   //console.log($(this).find("td:first"));
   var value= $(this).find(".danger td:first").clone();
   console.log(value);
   alert(value);
          
});
});